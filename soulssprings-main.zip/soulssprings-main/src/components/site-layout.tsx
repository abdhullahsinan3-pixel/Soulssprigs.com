import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Menu, X, Phone, Mail, Globe, MapPin } from "lucide-react";

const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/workshops", label: "Workshops" },
  { to: "/contact", label: "Contact" },
] as const;

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2.5 group">
      <span className="relative flex h-9 w-9 items-center justify-center rounded-full bg-[var(--sage)]/25 ring-1 ring-[var(--sage)]/40 transition-transform group-hover:scale-105">
        <svg viewBox="0 0 24 24" className="h-5 w-5 text-[var(--sage-deep)]" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 21c0-6 4-9 9-9-1 6-4 9-9 9Z" />
          <path d="M12 21c0-6-4-9-9-9 1 6 4 9 9 9Z" />
          <path d="M12 21V9" />
        </svg>
      </span>
      <span className="font-serif text-lg leading-none tracking-tight text-foreground">
        Soul Spring<span className="block text-[10px] uppercase tracking-[0.22em] text-muted-foreground mt-1">Counselling Center</span>
      </span>
    </Link>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="rounded-full px-4 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground [&.active]:bg-[var(--sage)]/20 [&.active]:text-foreground"
              activeOptions={{ exact: n.to === "/" }}
            >
              {n.label}
            </Link>
          ))}
          <Link
            to="/contact"
            className="ml-3 rounded-full bg-[var(--sage-deep)] px-5 py-2 text-sm font-medium text-primary-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
          >
            Book a session
          </Link>
        </nav>
        <button
          className="rounded-full p-2 text-foreground md:hidden"
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>
      {open && (
        <div className="border-t border-border/60 bg-background md:hidden">
          <div className="mx-auto flex max-w-6xl flex-col gap-1 px-5 py-4">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-muted [&.active]:bg-[var(--sage)]/20 [&.active]:text-foreground"
                activeOptions={{ exact: n.to === "/" }}
              >
                {n.label}
              </Link>
            ))}
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="mt-2 rounded-full bg-[var(--sage-deep)] px-5 py-2.5 text-center text-sm font-medium text-primary-foreground"
            >
              Book a session
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-[var(--cream)]">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-3 lg:px-8">
        <div>
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            A safe, compassionate space for mental wellness, personal growth, and emotional healing.
          </p>
        </div>
        <div>
          <h4 className="font-serif text-base text-foreground">Explore</h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {nav.map((n) => (
              <li key={n.to}>
                <Link to={n.to} className="hover:text-foreground">{n.label}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-serif text-base text-foreground">Get in touch</h4>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li className="flex items-center gap-2"><Phone className="h-4 w-4 text-[var(--sage-deep)]" /> <a href="tel:+94767732245" className="hover:text-foreground">076 773 2245</a></li>
            <li className="flex items-center gap-2"><Mail className="h-4 w-4 text-[var(--sage-deep)]" /> <span>Email upon request</span></li>
            <li className="flex items-center gap-2"><Globe className="h-4 w-4 text-[var(--sage-deep)]" /> Online across Sri Lanka & internationally</li>
            <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-[var(--sage-deep)]" /> In-person by appointment</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-2 px-5 py-5 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between lg:px-8">
          <span>© {new Date().getFullYear()} Soul Spring Counselling Center. All rights reserved.</span>
          <span>Services available in English · Sinhala · Tamil</span>
        </div>
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <SiteHeader />
      <main>{children}</main>
      <SiteFooter />
    </div>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  intro,
  center = false,
}: {
  eyebrow?: string;
  title: string;
  intro?: string;
  center?: boolean;
}) {
  return (
    <div className={center ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      {eyebrow && (
        <span className="inline-flex items-center gap-2 rounded-full border border-[var(--sage)]/40 bg-[var(--sage)]/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.18em] text-[var(--sage-deep)]">
          {eyebrow}
        </span>
      )}
      <h2 className="mt-4 font-serif text-3xl leading-[1.1] tracking-tight text-foreground md:text-4xl">
        {title}
      </h2>
      {intro && <p className="mt-4 text-base leading-relaxed text-muted-foreground">{intro}</p>}
    </div>
  );
}