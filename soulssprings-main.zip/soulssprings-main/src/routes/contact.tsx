import { createFileRoute } from "@tanstack/react-router";
import { PageShell, SectionHeader } from "@/components/site-layout";
import { Phone, Mail, Globe, MapPin, Send } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact | Soul Spring Counselling Center" },
      { name: "description", content: "Reach out to Soul Spring Counselling Center to book a confidential online or in-person session." },
      { property: "og:title", content: "Contact Soul Spring" },
      { property: "og:description", content: "Book a confidential counselling session — online or in person." },
    ],
  }),
});

function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-5 pb-8 pt-16 md:pt-20 lg:px-8">
        <SectionHeader
          eyebrow="Contact"
          title="Let’s begin the conversation."
          intro="Share a little about what you’re looking for and we’ll get back to you within one working day. Everything you share is kept confidential."
        />
      </section>

      <section className="mx-auto grid max-w-6xl gap-10 px-5 pb-24 lg:grid-cols-[1fr_1.2fr] lg:px-8">
        <aside className="space-y-4">
          {[
            { icon: Phone, label: "Phone", value: "076 773 2245", href: "tel:+94767732245" },
            { icon: Mail, label: "Email", value: "Available on request" },
            { icon: Globe, label: "Online sessions", value: "Across Sri Lanka & internationally" },
            { icon: MapPin, label: "In-person", value: "By appointment at agreed locations" },
          ].map(({ icon: Icon, label, value, href }) => (
            <div key={label} className="flex items-start gap-4 rounded-2xl border border-border/70 bg-card p-5">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--sage)]/20 text-[var(--sage-deep)]">
                <Icon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-[11px] uppercase tracking-widest text-muted-foreground">{label}</p>
                {href ? (
                  <a href={href} className="mt-1 block font-serif text-lg text-foreground hover:text-[var(--sage-deep)]">
                    {value}
                  </a>
                ) : (
                  <p className="mt-1 font-serif text-lg text-foreground">{value}</p>
                )}
              </div>
            </div>
          ))}
          <div className="rounded-2xl bg-[var(--sage-deep)] p-5 text-primary-foreground">
            <p className="font-serif text-lg leading-snug">Languages of service</p>
            <p className="mt-1 text-sm text-primary-foreground/80">English · Sinhala · Tamil</p>
          </div>
        </aside>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
          }}
          className="rounded-[2rem] border border-border/70 bg-card p-6 shadow-sm md:p-10"
        >
          {sent ? (
            <div className="flex min-h-[24rem] flex-col items-center justify-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[var(--sage)]/25 text-[var(--sage-deep)]">
                <Send className="h-6 w-6" />
              </span>
              <h3 className="mt-6 font-serif text-2xl text-foreground">Thank you for reaching out.</h3>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                Your message has been received. Someone from Soul Spring will get back to you soon.
              </p>
            </div>
          ) : (
            <>
              <div className="grid gap-5 md:grid-cols-2">
                <Field label="Your name" name="name" required />
                <Field label="Email or phone" name="contact" required />
              </div>
              <div className="mt-5 grid gap-5 md:grid-cols-2">
                <SelectField
                  label="Service of interest"
                  name="service"
                  options={[
                    "Psychological Counselling",
                    "Child Counselling",
                    "Educational Counselling",
                    "Family & Relationships",
                    "Personal Development",
                    "Workplace Counselling",
                    "Workshop / Training",
                  ]}
                />
                <SelectField
                  label="Preferred language"
                  name="language"
                  options={["English", "Sinhala", "Tamil"]}
                />
              </div>
              <div className="mt-5">
                <label className="block text-xs font-medium uppercase tracking-widest text-muted-foreground">
                  Message
                </label>
                <textarea
                  name="message"
                  rows={5}
                  required
                  placeholder="Share a little about what you’re looking for…"
                  className="mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-[var(--sage-deep)] focus:ring-2 focus:ring-[var(--sage)]/30"
                />
              </div>
              <button
                type="submit"
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[var(--sage-deep)] px-6 py-3 text-sm font-medium text-primary-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md md:w-auto"
              >
                Send message <Send className="h-4 w-4" />
              </button>
              <p className="mt-4 text-xs text-muted-foreground">
                Your information is treated with strict confidentiality.
              </p>
            </>
          )}
        </form>
      </section>
    </PageShell>
  );
}

function Field({ label, name, required }: { label: string; name: string; required?: boolean }) {
  return (
    <div>
      <label className="block text-xs font-medium uppercase tracking-widest text-muted-foreground">
        {label}
      </label>
      <input
        name={name}
        required={required}
        className="mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-[var(--sage-deep)] focus:ring-2 focus:ring-[var(--sage)]/30"
      />
    </div>
  );
}

function SelectField({ label, name, options }: { label: string; name: string; options: string[] }) {
  return (
    <div>
      <label className="block text-xs font-medium uppercase tracking-widest text-muted-foreground">
        {label}
      </label>
      <select
        name={name}
        className="mt-2 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-[var(--sage-deep)] focus:ring-2 focus:ring-[var(--sage)]/30"
      >
        <option value="">Select…</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}

