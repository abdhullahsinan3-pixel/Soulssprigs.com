import { createFileRoute } from "@tanstack/react-router";
import { PageShell, SectionHeader } from "@/components/site-layout";
import { Brain, Baby, GraduationCap, Users, Sprout, Briefcase } from "lucide-react";

export const Route = createFileRoute("/services")({
  component: ServicesPage,
  head: () => ({
    meta: [
      { title: "Counselling Services | Soul Spring Counselling Center" },
      { name: "description", content: "Psychological, child, educational, family, personal development and workplace counselling — online and in person, in English, Sinhala and Tamil." },
      { property: "og:title", content: "Our Counselling Services" },
      { property: "og:description", content: "Care shaped around every stage of life." },
    ],
  }),
});

const services = [
  {
    icon: Brain,
    title: "Psychological Counselling",
    intro: "Professional support for adults navigating emotional and mental health challenges.",
    items: [
      "Anxiety and stress",
      "Depression and emotional difficulties",
      "Grief and loss",
      "Trauma and life transitions",
      "Low self-esteem and confidence",
      "Anger management",
      "Relationship difficulties",
      "Personal growth and self-development",
    ],
  },
  {
    icon: Baby,
    title: "Child Counselling",
    intro: "Age-appropriate support for children’s emotional, behavioural and social development.",
    items: [
      "Anxiety and fears",
      "Behavioural difficulties",
      "School adjustment problems",
      "Emotional regulation",
      "Social and friendship issues",
      "Family changes and parental separation",
      "Academic stress",
      "Self-esteem and coping skills",
    ],
  },
  {
    icon: GraduationCap,
    title: "Educational Counselling",
    intro: "Helping students thrive academically and personally.",
    items: [
      "Academic stress management",
      "Study skills development",
      "Career guidance",
      "Examination anxiety",
      "Motivation and learning difficulties",
    ],
  },
  {
    icon: Users,
    title: "Family & Relationship Counselling",
    intro: "Support for couples and families to rebuild connection and understanding.",
    items: [
      "Family conflicts",
      "Couple and marital counselling",
      "Parenting guidance",
      "Communication difficulties",
      "Conflict resolution",
    ],
  },
  {
    icon: Sprout,
    title: "Personal Development",
    intro: "Grow into the person you want to become.",
    items: [
      "Goal setting",
      "Emotional intelligence",
      "Self-awareness",
      "Life skills development",
      "Leadership and confidence building",
    ],
  },
  {
    icon: Briefcase,
    title: "Workplace Counselling",
    intro: "Support for professionals and organisations to build healthier work lives.",
    items: [
      "Occupational stress",
      "Burnout prevention",
      "Work-life balance",
      "Career transitions",
      "Employee well-being",
    ],
  },
];

function ServicesPage() {
  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-5 pb-8 pt-16 md:pt-20 lg:px-8">
        <SectionHeader
          eyebrow="Our services"
          title="Care shaped around every stage of life."
          intro="Whether you are seeking support for yourself, your child, your family or your team — our services are designed to meet you where you are."
        />
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-5 pb-20 md:grid-cols-2 lg:px-8">
        {services.map(({ icon: Icon, title, intro, items }) => (
          <article
            key={title}
            className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-7 transition-all hover:-translate-y-1 hover:shadow-md"
          >
            <div className="flex items-start gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[var(--sage)]/20 text-[var(--sage-deep)]">
                <Icon className="h-6 w-6" />
              </span>
              <div>
                <h3 className="font-serif text-2xl text-foreground">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{intro}</p>
              </div>
            </div>
            <ul className="mt-6 grid gap-2 border-t border-border/60 pt-6 sm:grid-cols-2">
              {items.map((it) => (
                <li key={it} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--sage-deep)]" />
                  <span>{it}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </section>
    </PageShell>
  );
}

