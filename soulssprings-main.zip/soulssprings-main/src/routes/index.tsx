import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import {
  Brain, Baby, GraduationCap, Users, Sprout, Briefcase,
  ShieldCheck, HeartHandshake, Globe2, ArrowRight, Phone,
} from "lucide-react";
import heroImg from "@/assets/hero.jpg";
import aboutImg from "@/assets/about.jpg";
import { PageShell, SectionHeader } from "@/components/site-layout";

export const Route = createFileRoute("/")({
  component: Index,
});

const services = [
  { icon: Brain, title: "Psychological Counselling", desc: "Anxiety, depression, grief, trauma, self-esteem and more." },
  { icon: Baby, title: "Child Counselling", desc: "Age-appropriate support for emotional and behavioural growth." },
  { icon: GraduationCap, title: "Educational Counselling", desc: "Study skills, exam anxiety, motivation and career guidance." },
  { icon: Users, title: "Family & Relationships", desc: "Couples, parenting, communication and conflict resolution." },
  { icon: Sprout, title: "Personal Development", desc: "Goal setting, emotional intelligence and life skills." },
  { icon: Briefcase, title: "Workplace Counselling", desc: "Stress, burnout, work-life balance and career transitions." },
];

const values = [
  { icon: ShieldCheck, title: "Confidentiality", desc: "Every session is held in a private, ethical, protected space." },
  { icon: HeartHandshake, title: "Empathy & Respect", desc: "You are met without judgement, at your own pace." },
  { icon: Globe2, title: "Cultural Sensitivity", desc: "Care that honours your language, values and lived context." },
];

function Index() {
  return (
    <PageShell>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div
          aria-hidden
          className="absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(1200px 500px at 80% -10%, oklch(0.88 0.06 150 / 0.55), transparent 60%), radial-gradient(900px 400px at 0% 100%, oklch(0.90 0.08 55 / 0.35), transparent 60%)",
          }}
        />
        <div className="mx-auto grid max-w-6xl gap-12 px-5 pb-20 pt-14 md:pt-20 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:px-8">
          <div className="flex flex-col justify-center">
            <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[var(--sage)]/40 bg-white/60 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.2em] text-[var(--sage-deep)] backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--sage-deep)]" />
              Now welcoming new clients
            </span>
            <h1 className="mt-6 font-serif text-[2.5rem] leading-[1.05] tracking-tight text-foreground md:text-6xl">
              A journey towards <em className="not-italic text-[var(--sage-deep)]">hope</em> and well-being.
            </h1>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
              Soul Spring Counselling Center is a safe, compassionate space for mental wellness,
              personal growth and emotional healing — available online and in person across Sri Lanka,
              in English, Sinhala and Tamil.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-[var(--sage-deep)] px-6 py-3 text-sm font-medium text-primary-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
              >
                Book a session <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/services"
                className="inline-flex items-center gap-2 rounded-full border border-border bg-white/70 px-6 py-3 text-sm font-medium text-foreground backdrop-blur transition-colors hover:bg-white"
              >
                Explore services
              </Link>
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-6 border-t border-border/60 pt-6 text-left">
              {[
                ["3", "Languages"],
                ["Online", "& In-Person"],
                ["100%", "Confidential"],
              ].map(([k, v]) => (
                <div key={v}>
                  <dt className="font-serif text-2xl text-foreground">{k}</dt>
                  <dd className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative">
            <div className="relative overflow-hidden rounded-[2rem] shadow-xl ring-1 ring-black/5">
              <img
                src={heroImg}
                alt="Soft green leaves over calm water"
                width={1600}
                height={1200}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden max-w-[16rem] rounded-2xl border border-border/60 bg-background/95 p-4 shadow-lg backdrop-blur md:block">
              <p className="font-serif text-sm leading-snug text-foreground">
                “Every individual has the strength to create positive change.”
              </p>
              <p className="mt-2 text-[11px] uppercase tracking-widest text-muted-foreground">
                Our belief
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="mx-auto max-w-6xl px-5 py-20 lg:px-8">
        <SectionHeader
          eyebrow="What guides us"
          title="Care built on trust, warmth and integrity."
          intro="We believe healing begins where you feel truly safe. Our practice is grounded in three commitments to every person we work with."
        />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {values.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="group rounded-2xl border border-border/70 bg-card p-6 transition-all hover:-translate-y-1 hover:border-[var(--sage)]/60 hover:shadow-md"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--sage)]/20 text-[var(--sage-deep)]">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-5 font-serif text-xl text-foreground">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About strip */}
      <section className="bg-[var(--cream)]">
        <div className="mx-auto grid max-w-6xl gap-12 px-5 py-20 lg:grid-cols-2 lg:items-center lg:px-8">
          <div className="relative">
            <img
              src={aboutImg}
              alt="Hands holding a young green sprout"
              width={1400}
              height={1200}
              loading="lazy"
              className="w-full rounded-[2rem] object-cover shadow-lg ring-1 ring-black/5"
            />
          </div>
          <div>
            <SectionHeader
              eyebrow="About us"
              title="A compassionate space to grow, heal, and rediscover yourself."
              intro="Soul Spring supports individuals, couples, families and students in overcoming emotional, psychological and personal challenges — with cultural sensitivity at the heart of every conversation."
            />
            <ul className="mt-8 space-y-3 text-sm text-foreground">
              {[
                "Online counselling sessions worldwide",
                "Face-to-face sessions by appointment",
                "Workshops on mental well-being & life skills",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--sage-deep)]" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/about"
              className="mt-8 inline-flex items-center gap-2 font-medium text-[var(--sage-deep)] hover:gap-3 transition-all"
            >
              Learn more about us <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-6xl px-5 py-20 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <SectionHeader
            eyebrow="Our services"
            title="Care shaped around every stage of life."
            intro="From childhood to career, relationships to personal growth — we walk with you through it all."
          />
          <Link
            to="/services"
            className="inline-flex items-center gap-2 text-sm font-medium text-[var(--sage-deep)] hover:gap-3 transition-all"
          >
            All services <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ icon: Icon, title, desc }) => (
            <article
              key={title}
              className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card p-6 transition-all hover:-translate-y-1 hover:shadow-md"
            >
              <div className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-[var(--sage)] via-[var(--clay)]/60 to-[var(--sage)] opacity-0 transition-opacity group-hover:opacity-100" />
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--sage)]/15 text-[var(--sage-deep)]">
                <Icon className="h-5 w-5" />
              </span>
              <h3 className="mt-5 font-serif text-lg text-foreground">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{desc}</p>
            </article>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-5 pb-4 lg:px-8">
        <div className="relative overflow-hidden rounded-[2rem] bg-[var(--sage-deep)] px-8 py-14 text-primary-foreground shadow-xl md:px-14 md:py-16">
          <div
            aria-hidden
            className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl"
          />
          <div className="relative grid gap-8 md:grid-cols-[1.4fr_1fr] md:items-center">
            <div>
              <h3 className="font-serif text-3xl leading-tight md:text-4xl">
                Ready to take the first step?
              </h3>
              <p className="mt-3 max-w-lg text-sm leading-relaxed text-primary-foreground/80 md:text-base">
                Reach out for a confidential conversation. We’ll listen, understand, and walk with you.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 md:justify-end">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-medium text-[var(--sage-deep)] shadow-sm transition-transform hover:-translate-y-0.5"
              >
                Book a session <ArrowRight className="h-4 w-4" />
              </Link>
              <a
                href="tel:+94767732245"
                className="inline-flex items-center gap-2 rounded-full border border-white/30 px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-white/10"
              >
                <Phone className="h-4 w-4" /> 076 773 2245
              </a>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
