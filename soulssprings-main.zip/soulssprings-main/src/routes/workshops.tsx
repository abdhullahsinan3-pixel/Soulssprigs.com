import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, SectionHeader } from "@/components/site-layout";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/workshops")({
  component: WorkshopsPage,
  head: () => ({
    meta: [
      { title: "Workshops & Training | Soul Spring Counselling Center" },
      { name: "description", content: "Workshops on mental health awareness, stress management, positive parenting, workplace well-being, mindfulness and more." },
      { property: "og:title", content: "Workshops & Training Programmes" },
      { property: "og:description", content: "Practical, human-centred training on mental wellness and life skills." },
    ],
  }),
});

const workshops = [
  "Mental Health Awareness",
  "Stress Management",
  "Emotional Intelligence",
  "Positive Parenting",
  "Child Development & Well-being",
  "Communication Skills",
  "Conflict Resolution",
  "Self-Care & Mindfulness",
  "Student Well-being",
  "Workplace Mental Health",
  "Life Skills Development",
  "Suicide Prevention Awareness",
];

function WorkshopsPage() {
  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-5 pb-8 pt-16 md:pt-20 lg:px-8">
        <SectionHeader
          eyebrow="Workshops & training"
          title="Learning experiences that build well-being."
          intro="We design and deliver workshops for schools, workplaces and communities — grounded in psychological insight, warmth and practical tools."
        />
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-16 lg:px-8">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {workshops.map((w, i) => (
            <div
              key={w}
              className="group flex items-center gap-4 rounded-2xl border border-border/70 bg-card p-5 transition-all hover:-translate-y-0.5 hover:border-[var(--sage)]/60 hover:shadow-md"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--sage)]/15 font-serif text-sm text-[var(--sage-deep)]">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="text-sm font-medium text-foreground">{w}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-20 lg:px-8">
        <div className="rounded-[2rem] border border-border/70 bg-[var(--cream)] p-8 md:p-12">
          <div className="grid gap-8 md:grid-cols-[1.4fr_1fr] md:items-center">
            <div>
              <h3 className="font-serif text-2xl text-foreground md:text-3xl">
                Bring a workshop to your school, workplace or community.
              </h3>
              <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted-foreground">
                Every session is tailored to your audience and delivered in English, Sinhala or Tamil.
              </p>
            </div>
            <div className="md:justify-self-end">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-[var(--sage-deep)] px-6 py-3 text-sm font-medium text-primary-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
              >
                Enquire about a workshop <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}

