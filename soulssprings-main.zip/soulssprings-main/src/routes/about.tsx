import { createFileRoute } from "@tanstack/react-router";
import { PageShell, SectionHeader } from "@/components/site-layout";
import aboutImg from "@/assets/about.jpg";
import { ShieldCheck, HeartHandshake, Sparkles, Users, Scale, Globe2, Award } from "lucide-react";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About | Soul Spring Counselling Center" },
      { name: "description", content: "Learn about Soul Spring — our vision, mission and values as a trusted counselling center serving Sri Lanka in English, Sinhala and Tamil." },
      { property: "og:title", content: "About Soul Spring Counselling Center" },
      { property: "og:description", content: "A trusted, compassionate counselling center empowering emotional well-being." },
    ],
  }),
});

const values = [
  { icon: ShieldCheck, label: "Confidentiality" },
  { icon: HeartHandshake, label: "Respect & Empathy" },
  { icon: Award, label: "Professionalism" },
  { icon: Scale, label: "Integrity" },
  { icon: Users, label: "Inclusivity" },
  { icon: Sparkles, label: "Empowerment" },
  { icon: Globe2, label: "Cultural Sensitivity" },
];

function AboutPage() {
  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-5 pb-6 pt-16 md:pt-20 lg:px-8">
        <SectionHeader
          eyebrow="About us"
          title="Who we are"
          intro="Soul Spring Counselling Center is a professional counselling service dedicated to supporting individuals, couples, families and students in overcoming emotional, psychological and personal challenges. We offer confidential services in English, Sinhala and Tamil — both online and in person."
        />
      </section>

      <section className="mx-auto grid max-w-6xl gap-12 px-5 py-12 lg:grid-cols-2 lg:items-center lg:px-8">
        <img
          src={aboutImg}
          alt="Hands holding a small sprout"
          width={1400}
          height={1200}
          loading="lazy"
          className="w-full rounded-[2rem] object-cover shadow-lg ring-1 ring-black/5"
        />
        <div className="space-y-8">
          <div className="rounded-2xl border border-border/70 bg-card p-6">
            <h3 className="font-serif text-xl text-[var(--sage-deep)]">Our Vision</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              To become a trusted and compassionate counselling center that empowers individuals and communities to achieve emotional well-being, resilience and personal growth.
            </p>
          </div>
          <div className="rounded-2xl border border-border/70 bg-card p-6">
            <h3 className="font-serif text-xl text-[var(--sage-deep)]">Our Mission</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              To provide accessible, confidential and culturally sensitive counselling through online and face-to-face platforms in Sinhala, Tamil and English — while promoting mental health awareness and personal development through education and community engagement.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-[var(--cream)]">
        <div className="mx-auto max-w-6xl px-5 py-20 lg:px-8">
          <SectionHeader eyebrow="Our values" title="What we stand for." center />
          <ul className="mx-auto mt-12 flex max-w-4xl flex-wrap justify-center gap-3">
            {values.map(({ icon: Icon, label }) => (
              <li
                key={label}
                className="flex items-center gap-2 rounded-full border border-border/70 bg-background px-5 py-2.5 text-sm text-foreground shadow-sm"
              >
                <Icon className="h-4 w-4 text-[var(--sage-deep)]" />
                {label}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-5 py-20 text-center lg:px-8">
        <SectionHeader eyebrow="Confidentiality" title="Your story stays safe with us." center />
        <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground">
          All counselling sessions are conducted in a safe, supportive and confidential environment.
          Information shared during counselling is protected according to professional ethical standards.
        </p>
      </section>
    </PageShell>
  );
}

